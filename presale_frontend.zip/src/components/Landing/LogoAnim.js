import React from 'react';
import RocketAnim from './RocketAnim';
import '../../assets/logo.scss';

const LogoAnim = () => (
  <RocketAnim />
);
export default LogoAnim;